import os
from collections import defaultdict
from datetime import datetime, timedelta, timezone

import boto3

dynamodb = boto3.resource("dynamodb")
s3_client = boto3.client("s3")
ses_client = boto3.client("ses")
bedrock_agent_client = boto3.client("bedrock-agent")

METADATA_TABLE = os.environ["METADATA_TABLE"]
LANDING_BUCKET = os.environ["LANDING_BUCKET"]
SENDER_EMAIL = os.environ["SENDER_EMAIL"]
RECIPIENT_EMAILS = [e.strip() for e in os.environ["RECIPIENT_EMAILS"].split(",")]
KB_ID = os.environ["KB_ID"]
DATA_SOURCE_ID = os.environ["DATA_SOURCE_ID"]


def handler(event, context):
    _trigger_kb_sync()
    stats = _gather_stats()
    _send_digest(stats)
    return {"statusCode": 200, "body": "Digest sent"}


def _trigger_kb_sync():
    try:
        bedrock_agent_client.start_ingestion_job(
            knowledgeBaseId=KB_ID,
            dataSourceId=DATA_SOURCE_ID,
        )
        print("KB ingestion job started")
    except Exception as e:
        # Non-fatal — digest still sends even if sync fails
        print(f"Warning: KB sync not started: {e}")


def _gather_stats():
    table = dynamodb.Table(METADATA_TABLE)
    week_ago = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()

    # Full scan — document registry stays small (hundreds of items)
    items = []
    response = table.scan()
    items.extend(response["Items"])
    while "LastEvaluatedKey" in response:
        response = table.scan(ExclusiveStartKey=response["LastEvaluatedKey"])
        items.extend(response["Items"])

    new_this_week = [i for i in items if i.get("created_at", "") >= week_ago]

    by_industry = defaultdict(int)
    by_type = defaultdict(int)
    by_project = defaultdict(int)
    by_status = defaultdict(int)

    for item in items:
        meta = item.get("metadata", {})
        by_industry[meta.get("Industry", "Unknown")] += 1
        by_type[meta.get("Type", "Unknown")] += 1
        by_project[meta.get("Project", "Unknown")] += 1
        by_status[item.get("status", "unknown")] += 1

    s3_stats = _get_s3_stats()

    return {
        "total_documents": len(items),
        "new_this_week": len(new_this_week),
        "by_industry": dict(by_industry),
        "by_type": dict(by_type),
        "by_project": dict(by_project),
        "by_status": dict(by_status),
        "s3_object_count": s3_stats["count"],
        "s3_size_gb": s3_stats["size_gb"],
        "report_date": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC"),
    }


def _get_s3_stats():
    paginator = s3_client.get_paginator("list_objects_v2")
    count, size_bytes = 0, 0
    for page in paginator.paginate(Bucket=LANDING_BUCKET):
        for obj in page.get("Contents", []):
            if not obj["Key"].endswith(".metadata.json"):
                count += 1
                size_bytes += obj["Size"]
    return {"count": count, "size_gb": round(size_bytes / (1024**3), 2)}


def _send_digest(stats):
    subject = f"Knowledge Base Weekly Digest — {datetime.now(timezone.utc).strftime('%Y-%m-%d')}"
    ses_client.send_email(
        Source=SENDER_EMAIL,
        Destination={"ToAddresses": RECIPIENT_EMAILS},
        Message={
            "Subject": {"Data": subject},
            "Body": {
                "Html": {"Data": _build_html(stats)},
                "Text": {"Data": _build_text(stats)},
            },
        },
    )


def _build_html(stats):
    def rows(d):
        return "".join(
            f"<tr><td style='padding:6px 12px'>{k}</td>"
            f"<td style='padding:6px 12px;font-weight:bold'>{v}</td></tr>"
            for k, v in sorted(d.items(), key=lambda x: -x[1])
        )

    def section(title, d):
        return f"""
        <h3 style='margin-top:24px'>{title}</h3>
        <table border='1' cellpadding='0' cellspacing='0'
               style='border-collapse:collapse;width:100%;max-width:480px'>
          {rows(d)}
        </table>"""

    return f"""
    <html><body style='font-family:Arial,sans-serif;max-width:600px;margin:auto;color:#222'>
      <h2 style='border-bottom:2px solid #232F3E;padding-bottom:8px'>
        Knowledge Base Weekly Digest
      </h2>
      <p style='color:#666'>Report generated: {stats['report_date']}</p>

      <table border='1' cellpadding='0' cellspacing='0'
             style='border-collapse:collapse;width:100%;max-width:480px'>
        <tr style='background:#f5f5f5'>
          <td style='padding:6px 12px'>Total documents</td>
          <td style='padding:6px 12px;font-weight:bold'>{stats['total_documents']}</td>
        </tr>
        <tr>
          <td style='padding:6px 12px'>New this week</td>
          <td style='padding:6px 12px;font-weight:bold'>{stats['new_this_week']}</td>
        </tr>
        <tr style='background:#f5f5f5'>
          <td style='padding:6px 12px'>S3 objects (excl. sidecars)</td>
          <td style='padding:6px 12px;font-weight:bold'>{stats['s3_object_count']}</td>
        </tr>
        <tr>
          <td style='padding:6px 12px'>S3 storage</td>
          <td style='padding:6px 12px;font-weight:bold'>{stats['s3_size_gb']} GB</td>
        </tr>
      </table>

      {section('By Industry', stats['by_industry'])}
      {section('By Document Type', stats['by_type'])}
      {section('By Project', stats['by_project'])}
      {section('Ingestion Status', stats['by_status'])}
    </body></html>
    """


def _build_text(stats):
    def fmt(d):
        return "\n".join(
            f"  {k}: {v}" for k, v in sorted(d.items(), key=lambda x: -x[1])
        )

    return f"""Knowledge Base Weekly Digest
Report date: {stats['report_date']}

SUMMARY
  Total documents : {stats['total_documents']}
  New this week   : {stats['new_this_week']}
  S3 objects      : {stats['s3_object_count']}
  S3 storage      : {stats['s3_size_gb']} GB

BY INDUSTRY
{fmt(stats['by_industry'])}

BY DOCUMENT TYPE
{fmt(stats['by_type'])}

BY PROJECT
{fmt(stats['by_project'])}

INGESTION STATUS
{fmt(stats['by_status'])}
"""
