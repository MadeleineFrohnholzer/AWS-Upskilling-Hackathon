import json
import boto3
import os
from datetime import datetime, timezone

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

LANDING_BUCKET = os.environ["LANDING_BUCKET"]
METADATA_TABLE = os.environ["METADATA_TABLE"]


def handler(event, context):
    for record in event["Records"]:
        object_key = record["s3"]["object"]["key"]

        # Avoid infinite loop — skip sidecar files themselves
        if object_key.endswith(".metadata.json"):
            continue

        _process(object_key)


def _process(object_key):
    table = dynamodb.Table(METADATA_TABLE)

    result = table.get_item(Key={"object_key": object_key})
    item = result.get("Item", {})
    metadata = item.get("metadata", {})

    # Bedrock Knowledge Base expects this exact sidecar format
    sidecar = {
        "metadataAttributes": {
            k: {"type": "STRING", "value": str(v)}
            for k, v in metadata.items()
            if v  # skip empty values
        }
    }

    sidecar_key = f"{object_key}.metadata.json"
    s3_client.put_object(
        Bucket=LANDING_BUCKET,
        Key=sidecar_key,
        Body=json.dumps(sidecar, indent=2),
        ContentType="application/json",
    )

    table.update_item(
        Key={"object_key": object_key},
        UpdateExpression="SET #st = :s, updated_at = :t",
        ExpressionAttributeNames={"#st": "status"},
        ExpressionAttributeValues={
            ":s": "sidecar_created",
            ":t": datetime.now(timezone.utc).isoformat(),
        },
    )

    print(f"Created sidecar for {object_key}: {sidecar_key}")
