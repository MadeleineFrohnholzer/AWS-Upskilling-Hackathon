import json
import boto3
import os
import uuid
from datetime import datetime, timezone

s3_client = boto3.client("s3")
dynamodb = boto3.resource("dynamodb")

LANDING_BUCKET = os.environ["LANDING_BUCKET"]
METADATA_TABLE = os.environ["METADATA_TABLE"]

ALLOWED_EXTENSIONS = {".pdf", ".pptx", ".docx", ".txt", ".xlsx"}


def handler(event, context):
    try:
        body = json.loads(event.get("body") or "{}")
        filename = body.get("filename", "").strip()
        metadata = body.get("metadata", {})

        if not filename:
            return _response(400, {"error": "filename is required"})

        ext = os.path.splitext(filename)[1].lower()
        if ext not in ALLOWED_EXTENSIONS:
            return _response(400, {"error": f"file type not allowed: {ext}"})

        object_key = f"uploads/{uuid.uuid4()}/{filename}"

        # Store metadata in DynamoDB so the sidecar Lambda can read it on upload
        table = dynamodb.Table(METADATA_TABLE)
        table.put_item(
            Item={
                "object_key": object_key,
                "filename": filename,
                "metadata": metadata,
                "status": "pending",
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        )

        upload_url = s3_client.generate_presigned_url(
            "put_object",
            Params={
                "Bucket": LANDING_BUCKET,
                "Key": object_key,
                "ContentType": "application/octet-stream",
            },
            ExpiresIn=900,  # 15 minutes
        )

        return _response(200, {"upload_url": upload_url, "object_key": object_key})

    except Exception as e:
        print(f"Error: {e}")
        return _response(500, {"error": "internal server error"})


def _response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }
